/* soogy — мини-версия: вся логика в одном файле, без интернета и зависимостей */
(function () {
  "use strict";

  var $ = function (sel) { return document.querySelector(sel); };

  /* ===== Тема ===== */
  var THEME_KEY = "soogy:mini-theme";
  if (localStorage.getItem(THEME_KEY) === "light") document.body.classList.remove("dark");
  $("#themeBtn").addEventListener("click", function () {
    var dark = document.body.classList.toggle("dark");
    localStorage.setItem(THEME_KEY, dark ? "dark" : "light");
  });

  /* ===== Данные курсов ===== */
  var COURSES = [
    {
      id: "html", name: "HTML", glyph: "<>", lang: "html",
      desc: "Скелет страницы: теги, тексты, картинки, формы.",
      lessons: [
        { title: "Первая страница", file: "index.html",
          cards: [
            { file: "index.html", intro: "Любая веб-страница начинается с «каркаса»: доктайп, html, head и body.", code: "<!doctype html>\n<html>\n  <head>\n    <title>Моя страница</title>\n  </head>\n  <body>\n    Привет, мир!\n  </body>\n</html>", note: "Всё видимое живёт внутри <body>." }
          ],
          quiz: [
            { prompt: "Какой тег хранит видимое содержимое страницы?", correct: "<body>", wrong: ["<head>", "<html>", "<title>"], explain: "Всё, что видит пользователь, лежит внутри <body>." }
          ],
          task: {
            starter: "<!-- Сделайте заголовок и абзац -->\n",
            checks: [
              { label: "Есть <h1>", test: /<h1\b/i },
              { label: "Есть абзац <p>", test: /<p\b/i }
            ]
          }
        },
        { title: "Ссылки: href", file: "links.html",
          cards: [
            { file: "links.html", intro: "Атрибут href говорит ссылке, куда идти. Пишется внутри тега <a>.", code: "<a href=\"https://example.com\">В почтовый ящик не ходить</a>\n\n<a href=\"#top\">Внутри страницы</a>", note: "href — всегда значение-адрес в кавычках." }
          ],
          quiz: [
            { prompt: "Что делает атрибут href?", correct: "Указывает адрес, куда ведёт ссылка", wrong: ["Меняет цвет текста", "Открывает картинку", "Создаёт список"], explain: "href = гиперссылка-адрес внутри тега <a>." },
            { prompt: "Где пишется href?", correct: "Внутри открывающего тега <a>", wrong: ["После закрывающего </a>", "Внутри <body>", "Внутри <title>"], explain: "Атрибуты пишутся в открывающем теге." }
          ],
          task: {
            starter: "<!-- Сделайте ссылку на https://example.com -->\n",
            checks: [{ label: "Есть <a href=...>", test: /<a\b[^>]*href\s*=/i }]
          }
        }
      ]
    },
    {
      id: "css", name: "CSS", glyph: "#", lang: "css",
      desc: "Оформление: цвета, шрифты, отступы, сетки.",
      lessons: [
        { title: "Селекторы и цвет", file: "style.css",
          cards: [
            { file: "style.css", intro: "CSS выбирает элементы и красит их: селектор { свойство: значение; }", code: "h1 {\n  color: seagreen;\n  font-size: 32px;\n}", note: "Селектор слева, свойства в фигурных скобках." }
          ],
          quiz: [
            { prompt: "Какое свойство задаёт цвет текста?", correct: "color", wrong: ["background", "font-size", "border"], explain: "color — цвет текста, background — фон." }
          ],
          task: {
            starter: "h1 {\n  /* сделайте текст красным */\n}\n",
            checks: [{ label: "Есть color", test: /color\s*:/i }]
          }
        }
      ]
    },
    {
      id: "js", name: "JavaScript", glyph: "JS", lang: "js",
      desc: "Логика и интерактив: события, переменные, DOM.",
      lessons: [
        { title: "Переменные и alert", file: "script.js",
          cards: [
            { file: "script.js", intro: "Переменная — коробка со значением. let — когда значение меняется, const — когда нет.", code: "let счёт = 0;\nconst имя = \"Аня\";\n\nalert(\"Привет, \" + имя + \"!\");", note: "Строки — в кавычках, числа — без." }
          ],
          quiz: [
            { prompt: "Что выведет alert(\"2\" + 2)?", correct: "22", wrong: ["4", "2", "Ошибка"], explain: "Строка + число = склейка строк: \"22\"." }
          ],
          task: {
            starter: "// Объявите переменную name со значением \"Аня\"\n",
            checks: [{ label: "Есть let/const и имя", test: /(let|const)\s+name\s*=/i }]
          }
        }
      ]
    },
    {
      id: "py", name: "Python", glyph: "Py", lang: "python",
      desc: "Простые программы: print, input, условия.",
      lessons: [
        { title: "print() и переменные", file: "main.py",
          cards: [
            { file: "main.py", intro: "print() печатает текст в консоль. f-строка подставляет значения переменных.", code: "name = \"Аня\"\nprint(f\"Привет, {name}!\")", note: "Перед кавычками стоит буква f." }
          ],
          quiz: [
            { prompt: "Что напечатает print(f\"{2 + 3}\")?", correct: "5", wrong: ["{2 + 3}", "2 + 3", "Ошибку"], explain: "В f-строке выражение вычисляется." }
          ],
          task: {
            starter: "# Выведите Привет, мир!\n",
            checks: [{ label: "Есть print", test: /print\s*\(/ }]
          }
        }
      ]
    },
    {
      id: "cpp", name: "C++", glyph: "C+", lang: "cpp",
      desc: "Классика: типы, cin/cout, условия и циклы.",
      lessons: [
        { title: "cout и переменные", file: "main.cpp",
          cards: [
            { file: "main.cpp", intro: "cout печатает в консоль. Для чисел нужны типы: int, double.", code: "#include <iostream>\nusing namespace std;\n\nint main() {\n  int age = 14;\n  cout << \"Возраст: \" << age << endl;\n}", note: "<< — оператор вставки в поток." }
          ],
          quiz: [
            { prompt: "Какой тип для целых чисел?", correct: "int", wrong: ["double", "string", "bool"], explain: "int — целые, double — дробные." }
          ],
          task: {
            starter: "// Выведите Hello\n",
            checks: [{ label: "Есть cout", test: /cout\s*<</ }]
          }
        }
      ]
    },
    {
      id: "lua", name: "Lua", glyph: "Lu", lang: "lua",
      desc: "Лёгкий язык для Roblox: переменные, циклы, функции.",
      lessons: [
        { title: "print и переменные", file: "main.lua",
          cards: [
            { file: "main.lua", intro: "local создаёт переменную, print печатает. Конкатенация — две точки ..", code: "local name = \"Аня\"\nprint(\"Привет, \" .. name .. \"!\")", note: "local — чтобы переменная не была глобальной." }
          ],
          quiz: [
            { prompt: "Как склеить строки в Lua?", correct: "..", wrong: ["+", "&", "concat"], explain: "Оператор конкатенации в Lua — «..»." }
          ],
          task: {
            starter: "-- Выведите Hello\n",
            checks: [{ label: "Есть print", test: /print\s*\(/ }]
          }
        }
      ]
    }
  ];

  /* ===== Прогресс ===== */
  var PROGRESS_KEY = "soogy:mini-progress";
  var progress = {};
  try { progress = JSON.parse(localStorage.getItem(PROGRESS_KEY) || "{}") || {}; } catch (e) { progress = {}; }
  function saveProgress() {
    try { localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress)); } catch (e) {}
  }
  function doneCount(course) {
    return course.lessons.filter(function (l) { return progress[course.id + ":" + l.title]; }).length;
  }

  /* ===== Рендер курсов ===== */
  var grid = $("#courseGrid");
  var activeCourse = COURSES[0];
  var activeLesson = null;

  function renderCourses() {
    grid.innerHTML = "";
    COURSES.forEach(function (c) {
      var el = document.createElement("button");
      el.className = "card";
      el.type = "button";
      var pct = Math.round((doneCount(c) / c.lessons.length) * 100);
      el.innerHTML =
        '<div class="card-top"><span class="card-glyph">' + c.glyph + '</span><span class="card-count">' +
        doneCount(c) + " / " + c.lessons.length + '</span></div>' +
        '<div class="card-title">' + c.name + '</div>' +
        '<p class="card-desc">' + c.desc + "</p>" +
        '<div class="card-progress"><i style="width:' + pct + '%"></i></div>';
      el.addEventListener("click", function () {
        activeCourse = c;
        renderLessons();
        document.getElementById("lesson").scrollIntoView({ behavior: "smooth" });
      });
      grid.appendChild(el);
    });
  }

  /* ===== Рендер уроков ===== */
  var lessonTabs = $("#lessonTabs");
  var lessonList = $("#lessonList");

  function renderTabs() {
    lessonTabs.innerHTML = "";
    COURSES.forEach(function (c) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "side-tab" + (c === activeCourse ? " active" : "");
      b.textContent = c.name;
      b.addEventListener("click", function () {
        activeCourse = c;
        renderLessons();
      });
      lessonTabs.appendChild(b);
    });
  }

  function renderLessons() {
    renderTabs();
    renderCourses();
    lessonList.innerHTML = "";
    activeCourse.lessons.forEach(function (l) {
      var li = document.createElement("li");
      var b = document.createElement("button");
      b.type = "button";
      var done = !!progress[activeCourse.id + ":" + l.title];
      b.className = activeLesson === l ? "active" : "";
      b.innerHTML =
        "<span>" + l.title + "</span>" +
        (done ? '<span class="done-badge">✓</span>' : "");
      b.addEventListener("click", function () {
        activeLesson = l;
        renderLesson();
      });
      li.appendChild(b);
      lessonList.appendChild(li);
    });
  }

  /* ===== Рендер урока ===== */
  var lessonTitle = $("#lessonTitle");
  var lessonCards = $("#lessonCards");
  var quizBox = $("#quizBox");
  var taskBox = $("#taskBox");
  var taskCode = $("#taskCode");
  var taskFile = $("#taskFile");
  var taskChecks = $("#taskChecks");
  var taskPreview = $("#taskPreview");

  function renderLesson() {
    if (!activeLesson) return;
    var l = activeLesson;
    lessonTitle.textContent = activeCourse.name + " · " + l.title;
    renderLessons();

    /* Карточки */
    lessonCards.innerHTML = "";
    l.cards.forEach(function (c) {
      var el = document.createElement("div");
      el.className = "tcard";
      el.innerHTML =
        '<div class="tcard-head"><span>' + c.file + '</span></div>' +
        '<p class="tcard-intro">' + c.intro + "</p>" +
        '<pre class="tcard-body">' + escapeHtml(c.code) + "</pre>" +
        (c.note ? '<div class="tcard-note">💡 ' + c.note + "</div>" : "");
      lessonCards.appendChild(el);
    });

    /* Квиз */
    quizBox.classList.toggle("hidden", !l.quiz);
    if (l.quiz) {
      quizBox.innerHTML = '<div class="quiz-title">Проверьте себя</div>';
      l.quiz.forEach(function (q) {
        var box = document.createElement("div");
        box.className = "q";
        box.innerHTML = '<div class="q-prompt">' + q.prompt + '</div><div class="q-opts"></div>';
        var opts = box.querySelector(".q-opts");
        var options = q.wrong.concat([q.correct]);
        shuffle(options);
        options.forEach(function (text) {
          var b = document.createElement("button");
          b.type = "button";
          b.className = "q-opt";
          b.textContent = text;
          b.addEventListener("click", function () {
            if (box.querySelector(".q-explain")) return;
            if (text === q.correct) b.classList.add("correct");
            else b.classList.add("wrong");
            var ex = document.createElement("p");
            ex.className = "q-explain";
            ex.textContent = (text === q.correct ? "✓ " : "✗ ") + q.explain;
            box.appendChild(ex);
          });
          opts.appendChild(b);
        });
        quizBox.appendChild(box);
      });
    }

    /* Практика */
    taskBox.classList.toggle("hidden", !l.task);
    if (l.task) {
      taskFile.textContent = l.file;
      var draftKey = "soogy:mini-draft:" + activeCourse.id + ":" + l.title;
      taskCode.value = localStorage.getItem(draftKey) || l.task.starter;
      taskCode.oninput = function () {
        localStorage.setItem(draftKey, taskCode.value);
      };
      renderChecks(l.task.checks, []);
      runTask();
    }
  }

  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function shuffle(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }

  /* ===== Песочница и проверка ===== */
  function renderChecks(checks, results) {
    taskChecks.innerHTML = "";
    checks.forEach(function (c, i) {
      var li = document.createElement("li");
      li.textContent = c.label;
      if (results[i]) li.classList.add("ok");
      taskChecks.appendChild(li);
    });
  }

  function runTask() {
    if (!activeLesson || !activeLesson.task) return;
    var code = taskCode.value;
    var results = activeLesson.task.checks.map(function (c) {
      return c.test.test(code);
    });
    renderChecks(activeLesson.task.checks, results);

    var allOk = results.every(Boolean);
    var key = activeCourse.id + ":" + activeLesson.title;
    if (allOk && !progress[key]) {
      progress[key] = true;
      saveProgress();
      renderCourses();
      renderLessons();
    }

    /* Предпросмотр для HTML/CSS-кода */
    var ext = (activeLesson.file.split(".").pop() || "").toLowerCase();
    if (ext === "html") {
      taskPreview.srcdoc = code;
    } else if (ext === "css") {
      taskPreview.srcdoc =
        "<style>body{font-family:sans-serif;padding:16px}" + code + "</style><h1>Заголовок</h1><p>Пример текста.</p>";
    } else {
      taskPreview.srcdoc =
        "<body style=\"font-family:monospace;padding:12px;font-size:13px\">Вывод программы появится здесь после запуска в полной версии soogy.</body>";
    }
  }

  $("#runBtn").addEventListener("click", runTask);
  $("#resetBtn").addEventListener("click", function () {
    if (!activeLesson || !activeLesson.task) return;
    taskCode.value = activeLesson.task.starter;
    localStorage.setItem("soogy:mini-draft:" + activeCourse.id + ":" + activeLesson.title, taskCode.value);
    runTask();
  });

  /* ===== Старт ===== */
  renderCourses();
  renderLessons();
})();
